<?php
/* -----------------------------------------------------------------------------
 * This is a sample file for custom layout. You can edit this file to have your own layout.
 * -------------------------------------------------------------------------- */
include( 'single_classic.php' );
?>