<!-- Bottom Bar -->
<div class="vw-bottom-bar">
	<div class="container">
		<div class="row">
			<div class="col-sm-12">

				<div class="vw-bottom-bar-inner">
					<div class="vw-bottom-bar-left">
						<?php get_template_part( 'templates/menu-bottom' ); ?>
					</div>

					<div class="vw-bottom-bar-right">
						<?php vw_the_copyright(); ?>
					</div>
				</div>

			</div>
		</div>
	</div>
</div>
<!-- End Bottom Bar -->