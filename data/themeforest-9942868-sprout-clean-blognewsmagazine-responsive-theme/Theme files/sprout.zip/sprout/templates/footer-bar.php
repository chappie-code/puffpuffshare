<!-- Footer Bar -->
<div class="vw-footer-bar">

	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<div class="vw-footer-bar-inner">

					<div class="vw-footer-bar-left">
						
					</div>
					
					<div class="vw-footer-bar-right">
						
					</div>

				</div>
			</div>
		</div>
	</div>

</div>
<!-- End Footer Bar -->