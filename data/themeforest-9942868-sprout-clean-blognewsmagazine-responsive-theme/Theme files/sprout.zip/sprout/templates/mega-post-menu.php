<ul class="sub-posts clearfix">
	<li class="col-xs-12">
		<?php get_template_part( 'templates/post-loop/loop-mega-menu-3-col' ); ?>
	</li>
</ul>