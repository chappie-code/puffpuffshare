<div class="vw-related-posts vw-related-posts-style-default">
	<h3 class="vw-related-posts-title"><span><?php _e( 'Related Posts', 'envirra' ) ?></span></h3>

	<?php get_template_part( 'templates/post-loop/loop', vw_get_theme_option( 'related_post_layout' ) ); ?>

</div>