<div class="vw-post-footer-section-custom-2">
	<?php echo do_shortcode( vw_get_theme_option( 'post_footer_section_custom_2' ) ); ?>
</div>