# ACF - Sidebar Selector Field

This plugin adds a sidebar selector to ACF, allowing you to select a sidebar as a setting. For information about the base plugin which is required for the role selector to work, take a look at [ACF on Github](https://github.com/elliotcondon/acf) or the official [ACF Homepage](http://www.advancedcustomfields.com/).

-----------------------

* Readme : https://github.com/danielpataki/acf-sidebar-selector/blob/master/readme.txt
* WordPress repository: http://wordpress.org/plugins/acf-sidebar-selector-field/

-----------------------

Special thanks to [Elliot Condon](http://elliotcondon.com) for making the wonderful [ACF plugin](advancedcustomfields.com) in the first place.