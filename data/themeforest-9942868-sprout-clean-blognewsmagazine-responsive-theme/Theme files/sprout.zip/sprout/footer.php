
			<?php get_template_part( '/templates/site-footer' ); ?>

		</div>
		<!-- End Site Wrapper -->
		
		<!-- WP Footer -->
		<?php wp_footer(); ?>
		<!-- End WP Footer -->

	</body>

</html>