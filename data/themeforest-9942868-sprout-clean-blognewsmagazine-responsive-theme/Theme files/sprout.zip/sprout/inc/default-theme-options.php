<?php
/* -----------------------------------------------------------------------------
 * This file will be loaded only ReduxFramework is not activated
 * -------------------------------------------------------------------------- */

global $vw_sprout;
$vw_sprout = json_decode( '{"last_tab":"13","site_enable_open_graph":"1","site_force_enable_rtl":"0","page_force_disable_comments":"1","site_404":"","tracking_code":"                                            ","site_layout":"full-width","site_top_bar":"breaking-social","site_header_layout":"left-logo","site_enable_sticky_menu":"1","site_enable_sticky_sidebar":"1","site_header_padding":{"padding-top":"15px","padding-bottom":"10px"},"header_ads_banner":"                        <img src=\"http:\/\/placehold.it\/728x90\/b8b8b8\/fff&text=Ads+728x90\">                    ","header_ads_leaderboard":"                        <img src=\"http:\/\/placehold.it\/468x60\/b8b8b8\/fff&text=Ads+468x60\">                    ","site_bottom_bar":"copyright-social","copyright_text":"Copyright \u00a9, All Rights Reserved.","site_footer_layout":"4,4,4","blog_default_layout":"masonry-grid-2-col","blog_default_sidebar_position":"right","blog_default_left_sidebar":"blog-left-sidebar","blog_default_right_sidebar":"blog-right-sidebar","blog_excerpt_length":"50","full_featured_image_height":"150","blog_enable_post_views":"1","post_default_layout":"full-width","post_default_sidebar_position":"right","post_footer_sections":{"enabled":{"placebo":"placebo","post-navigation":"Next\/Previous Post","about-author":"About Author","related-posts":"Related Posts","comments":"Comments"},"disabled":{"placebo":"placebo","custom-1":"Custom Section 1","custom-2":"Custom Section 2"}},"post_footer_section_custom_1":"","post_footer_section_custom_2":"","related_post_layout":"block-2-grid-3-col","related_post_count":"6","blog_enable_custom_tiled_gallery":"1","blog_custom_tiled_gallery_layout":"213","typography_header":{"font-family":"Open Sans","font-options":"","google":"1","font-backup":"","font-weight":"800","font-style":"","subsets":"","text-transform":"uppercase","letter-spacing":"-1px","color":"#3e3e3e"},"typography_main_menu":{"font-family":"Open Sans","font-options":"","google":"1","font-backup":"","font-weight":"700","font-style":"","subsets":"","font-size":"13px","letter-spacing":"1px","color":"#fff"},"typography_body":{"font-family":"Open Sans","font-options":"","google":"1","font-backup":"","font-weight":"400","font-style":"","subsets":"","font-size":"14px","color":"#666666"},"custom_font1_ttf":{"url":"","id":"","height":"","width":"","thumbnail":""},"custom_font1_woff":{"url":"","id":"","height":"","width":"","thumbnail":""},"custom_font1_svg":{"url":"","id":"","height":"","width":"","thumbnail":""},"custom_font1_eot":{"url":"","id":"","height":"","width":"","thumbnail":""},"custom_font2_ttf":{"url":"","id":"","height":"","width":"","thumbnail":""},"custom_font2_woff":{"url":"","id":"","height":"","width":"","thumbnail":""},"custom_font2_svg":{"url":"","id":"","height":"","width":"","thumbnail":""},"custom_font2_eot":{"url":"","id":"","height":"","width":"","thumbnail":""},"logo":{"url":"http:\/\/envirra.com\/themes\/sprout\/wp-content\/uploads\/2014\/12\/logo2.png","id":"126","height":"47","width":"136","thumbnail":"http:\/\/envirra.com\/themes\/sprout\/wp-content\/uploads\/2014\/12\/logo2.png"},"logo_2x":{"url":"http:\/\/envirra.com\/themes\/sprout\/wp-content\/uploads\/2014\/12\/logo2@2x.png","id":"127","height":"94","width":"272","thumbnail":"http:\/\/envirra.com\/themes\/sprout\/wp-content\/uploads\/2014\/12\/logo2@2x-150x94.png"},"logo_margin":{"margin-top":"30px","margin-right":"0","margin-bottom":"30px","margin-left":"0","units":"px"},"nav_logo":{"url":"http:\/\/envirra.com\/themes\/sprout\/wp-content\/uploads\/2014\/12\/logo2.png","id":"126","height":"47","width":"136","thumbnail":"http:\/\/envirra.com\/themes\/sprout\/wp-content\/uploads\/2014\/12\/logo2.png"},"nav_logo_margin":{"margin-top":"8px","margin-right":"10px","margin-bottom":"10px","margin-left":"0","units":"px"},"fav_icon":{"url":"","id":"","height":"","width":"","thumbnail":""},"fav_icon_iphone":{"url":"","id":"","height":"","width":"","thumbnail":""},"fav_icon_iphone_retina":{"url":"","id":"","height":"","width":"","thumbnail":""},"fav_icon_ipad":{"url":"","id":"","height":"","width":"","thumbnail":""},"fav_icon_ipad_retina":{"url":"","id":"","height":"","width":"","thumbnail":""},"icon_elusive":"0","icon_awesome":"0","icon_entypo":"0","icon_typicons":"0","social_delicious":"","social_digg":"","social_dribbble":"","social_facebook":"https:\/\/facebook.com","social_flickr":"","social_forrst":"","social_github":"","social_googleplus":"https:\/\/plus.google.com","social_instagram":"","social_lastfm":"","social_linkedin":"","social_pinterest":"","social_rss":"","social_skype":"","social_tumblr":"","social_twitter":"https:\/\/twitter.com","social_vimeo":"","social_yahoo":"","social_youtube":"","bxslider_auto_start":"1","bxslider_pause_on_hover":"1","bxslider_slide_duration":"4000","bxslider_transition_speed":"500","accent_color":"#3274b1","site_background":{"background-color":"","background-repeat":"","background-size":"","background-attachment":"","background-position":"","background-image":"","media":{"id":"","height":"","width":"","thumbnail":""}},"header_background":{"background-color":"#f5f5f5","background-repeat":"","background-size":"","background-attachment":"","background-position":"","background-image":"","media":{"id":"","height":"","width":"","thumbnail":""}},"body_background":{"background-color":"#ffffff"},"topbar_background":"#333333","top_main_menu_link":{"regular":"#888888","hover":"#3e3e3e"},"top_sub_menu_background":"#ffffff","top_sub_menu_link":{"regular":"#111111","hover":"#888888"},"top_sub_menu_hover_background":"#f5f5f5","main_menu_background":{"color":"#ffffff","alpha":"0.00"},"main_main_menu_link":{"regular":"#888888","hover":"#111111"},"main_main_menu_hover_background":"#ffffff","main_sub_menu_background":"#ffffff","main_sub_menu_link":{"regular":"#111111","hover":"#888888"},"main_sub_menu_hover_background":"#f5f5f5","footer_background":{"background-color":"#222222","background-repeat":"","background-size":"","background-attachment":"","background-position":"","background-image":"","media":{"id":"","height":"","width":"","thumbnail":""}},"footer_header_color":"#ffffff","footer_color":"#dcdcdc","bottombar_background":"#111111","bottombar_color":"#b4b4b4","woocommerce_show_breaking_news":"0","woocommerce_show_breadcrumb":"1","woocommerce_product_default_sidebar_position":"right","woocommerce_product_default_left_sidebar":"blog-left-sidebar","woocommerce_product_default_right_sidebar":"sidebar-10","bbpress_forum_page":"","bbpress_show_breaking_news":"0","bbpress_default_sidebar_position":"right","bbpress_default_left_sidebar":"blog-left-sidebar","bbpress_default_right_sidebar":"sidebar-11","buddypress_show_breaking_news":"0","buddypress_default_sidebar_position":"right","buddypress_default_left_sidebar":"blog-left-sidebar","buddypress_default_right_sidebar":"blog-right-sidebar","custom_css":"                                            ","custom_js":"                                            ","custom_jquery":"                                            ","section":"","opt-import-export":"","redux-backup":"1"}',true );

add_action( 'wp_head', 'vw_render_default_theme_script', 99 );
if ( ! function_exists( 'vw_render_default_theme_script' ) ) {
	function vw_render_default_theme_script() {
		?>

		<link rel='stylesheet' id='redux-google-fonts-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A300%2C400%2C600%2C700%2C800%2C300italic%2C400italic%2C600italic%2C700italic%2C800italic&#038;ver=1421304082' type='text/css' media='all' />

<!-- Theme's Default Custom CSS -->
	<style type="text/css">
		
		a, a:hover,
		.vw-page-title-box .vw-label,
		.vw-post-categories a,
		.vw-page-subtitle,
		.vw-review-total-score,
		.vw-breaking-news-date,
		.vw-date-box-date,
		.vw-post-style-classic .vw-post-box-title a:hover,
		.vw-post-likes-count.vw-post-liked .vw-icon,
		.vw-menu-location-bottom .main-menu-link:hover,
		.vw-accordion-header.ui-accordion-header-active span,
		.vw-404-text,
		#wp-calendar thead,
		.vw-accordion .ui-state-hover span,
		.vw-breadcrumb a:hover,
		.vw-post-tabed-tab.ui-state-active, .vw-post-tabed-tab.ui-state-hover a,
		.vw-tabs.vw-style-top-tab .vw-tab-title.active,
		h1 em, h2 em, h3 em, h4 em, h5 em, h6 em
		{
			color: #3274b1;
		}

		.vw-site-social-profile-icon:hover,
		.vw-breaking-news-label,
		.vw-author-socials a:hover,
		.vw-post-style-box:hover,
		.vw-post-box:hover .vw-post-format-icon i,
		.vw-gallery-direction-button:hover,
		.widget_tag_cloud .tagcloud a:hover,
		.vw-page-navigation-pagination .page-numbers:hover,
		.vw-page-navigation-pagination .page-numbers.current,
		#wp-calendar tbody td:hover,
		.vw-widget-category-post-count,
		.vwspc-section-full-page-link:hover .vw-button,
		
		.vw-tag-links a,
		.vw-hamburger-icon:hover,
		.pace .pace-progress,
		.vw-review-summary-bar .vw-review-score,
		.vw-review-total-score span, .vw-review-score-percentage .vw-review-item-score, .vw-review-score-points .vw-review-item-score,
		.vw-pricing-featured .vw-pricing-header,
		.vw-bxslider .bx-prev:hover, .vw-bxslider .bx-next:hover,
		.no-touch input[type=button]:hover, .no-touch input[type=submit]:hover, .no-touch button:hover, .no-touch .vw-button:hover,
		.vw-page-content .vw-page-title-box .vw-label,
		.vw-breaking-news-title,
		.vw-post-style-small-left-thumbnail .vw-post-view-count,
		.vw-quote-icon,
		.vw-dropcap-circle, .vw-dropcap-box,
		.vw-accordion .ui-icon:before,
		.vw-post-categories .vw-sticky-link
		{
			background-color: #3274b1;
		}

		.vw-about-author-section .vw-author-name,
		.vw-post-meta-large .vw-date-box,
		#wp-calendar caption,
		.vw-widget-feedburner-text,
		.vw-login-title,
		.widget_search label,
		.widget_vw_widget_author .vw-widget-author-title
		{
			border-color: #3274b1;
		}

		.vw-menu-location-top.sf-arrows .main-menu-link.sf-with-ul:after {
			border-top-color: #888888;
		}
		.vw-menu-location-top.sf-arrows .sub-menu-link.sf-with-ul:after {
			border-left-color: #888888;
		}

		.sf-arrows > li > .sf-with-ul:focus:after, .sf-arrows > li:hover > .sf-with-ul:after, .sf-arrows > .sfHover > .sf-with-ul:after {
			border-top-color: #3274b1 !important;
		}

		.vw-menu-location-top .main-menu-link,
		.vw-top-bar .vw-site-social-profile-icon,
		.vw-top-bar-right .vw-cart-button, .vw-top-bar-right .vw-instant-search-buton {
			color: #888888;
		}
		
		.vw-menu-location-main .main-menu-item.current-menu-item,
		.vw-menu-location-main .main-menu-item.current-menu-parent,
		.vw-menu-location-main .main-menu-item.current-menu-ancestor {
			background-color: #ffffff;
			color: #3e3e3e;
		}

		.vw-menu-location-top .main-menu-item:hover .main-menu-link {
			color: #3e3e3e;
		}

		/* Header font */
		input[type=button], input[type=submit], button, .vw-button,
		.vw-header-font-family,
		.vw-copyright {
			font-family: Open Sans;
		}

		/* Body font */
		.vw-breaking-news-link {
			font-family: Open Sans;
		}

		.vw-page-title-section.vw-has-background .col-sm-12 {
			padding-top: 150px;
		}

		.vw-sticky-wrapper.is-sticky .vw-menu-main-wrapper.vw-sticky {
			background-color: rgba(255,255,255,0.95);
		}

		/* WooCommerce */
		
		.woocommerce ul.products li.product .price, .woocommerce-page ul.products li.product .price,
		.woocommerce #content div.product p.price, .woocommerce #content div.product span.price, .woocommerce div.product p.price, .woocommerce div.product span.price, .woocommerce-page #content div.product p.price, .woocommerce-page #content div.product span.price, .woocommerce-page div.product p.price, .woocommerce-page div.product span.price,
		.woocommerce .widget_shopping_cart .widget_shopping_cart_content .total .amount, .woocommerce-page .widget_shopping_cart .widget_shopping_cart_content .total .amount,
		.woocommerce .product_list_widget .quantity, .woocommerce .product_list_widget .amount, .woocommerce-page .product_list_widget .quantity, .woocommerce-page .product_list_widget .amount
		{
			color: #3274b1;
		}

		.woocommerce .widget_layered_nav_filters ul li a, .woocommerce-page .widget_layered_nav_filters ul li a,
		.widget_product_tag_cloud .tagcloud a:hover, .widget_tag_cloud .tagcloud a:hover,
		.woocommerce #content input.button:hover, .woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover, .woocommerce-page #content input.button:hover, .woocommerce-page #respond input#submit:hover, .woocommerce-page a.button:hover, .woocommerce-page button.button:hover, .woocommerce-page input.button:hover, .woocommerce #content input.button.alt:hover, .woocommerce #respond input#submit.alt:hover, .woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover, .woocommerce-page #content input.button.alt:hover, .woocommerce-page #respond input#submit.alt:hover, .woocommerce-page a.button.alt:hover, .woocommerce-page button.button.alt:hover, .woocommerce-page input.button.alt:hover,
		.woocommerce span.onsale, .woocommerce-page span.onsale,
		.vw-cart-button-count
		{
			background-color: #3274b1;
		}

		/* bbPress */
		#bbpress-forums .bbp-forum-title {
			color: #3e3e3e;
		}

		/* buddypress */
		#buddypress div.item-list-tabs ul li.current a:hover, #buddypress div.item-list-tabs ul li.selected a:hover,
		#buddypress .comment-reply-link:hover, #buddypress a.button:hover, #buddypress button:hover, #buddypress div.generic-button a:hover, #buddypress input[type=button]:hover, #buddypress input[type=reset]:hover, #buddypress input[type=submit]:hover, #buddypress ul.button-nav li a:hover, a.bp-title-button:hover
		{
			background-color: #3274b1;
		}

		/* Custom Styles */
		                                            	</style>
	<!-- End Theme's Custom CSS -->
	<style type="text/css" title="dynamic-css" class="options-output">.vw-site-header-inner{padding-top:15px;padding-bottom:10px;}h1, h2, h3, h4, h5, h6, .vw-header-font,.vw-post-box.vw-post-format-link a,.vw-social-counter-count,.vw-page-navigation-pagination .page-numbers,#wp-calendar caption,.vw-accordion-header-text,.vw-tab-title,.vw-review-item-title{font-family:Open Sans;text-transform:uppercase;letter-spacing:-1px;font-weight:800;font-style:normal;color:#3e3e3e;}.vw-menu-location-main .main-menu-link{font-family:Open Sans;letter-spacing:1px;font-weight:700;font-style:normal;color:#fff;font-size:13px;}body,cite{font-family:Open Sans;font-weight:400;font-style:normal;color:#666666;font-size:14px;}.vw-logo-link{margin-top:30px;margin-right:0;margin-bottom:30px;margin-left:0;}.vw-menu-additional-logo img{margin-top:8px;margin-right:10px;margin-bottom:10px;margin-left:0;}.vw-site-header,.vw-site-header-background{background-color:#f5f5f5;}.vw-site-wrapper,.vw-page-navigation-pagination{background-color:#ffffff;}.vw-top-bar{background:#333333;}.vw-menu-location-top .sub-menu,.vw-menu-location-top .main-menu-item:hover .main-menu-link{background:#ffffff;}.vw-menu-location-top .sub-menu-link{color:#111111;}.vw-menu-location-top .sub-menu-link:hover{color:#888888;}.vw-menu-location-top .sub-menu-link:hover{background:#f5f5f5;}.vw-menu-main-wrapper{background:transparent;}.vw-menu-location-main .main-menu-item{color:#888888;}.vw-menu-location-main .main-menu-item:hover{color:#111111;}.vw-menu-location-main .main-menu-item:hover .main-menu-link{background:#ffffff;}.vw-menu-location-main .sub-menu{background:#ffffff;}.vw-menu-location-main .sub-menu-link{color:#111111;}.vw-menu-location-main .sub-menu-link:hover{color:#888888;}.vw-menu-location-main .sub-menu-link:hover{background:#f5f5f5;}.vw-site-footer{background-color:#222222;}.vw-site-footer-sidebars h1,.vw-site-footer-sidebars h2,.vw-site-footer-sidebars h3,.vw-site-footer-sidebars h4,.vw-site-footer-sidebars h5,.vw-site-footer-sidebars h6,.vw-site-footer-sidebars .widget-title,.vw-site-footer-sidebars .vw-widget-category-title{color:#ffffff;}.vw-site-footer-sidebars{color:#dcdcdc;}.vw-bottom-bar{background:#111111;}.vw-bottom-bar{color:#b4b4b4;}</style>	
		<?php
	}
}