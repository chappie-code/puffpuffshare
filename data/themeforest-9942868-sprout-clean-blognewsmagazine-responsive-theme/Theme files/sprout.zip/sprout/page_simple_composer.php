<?php
/*
Template Name: VW Simple Page Composer
*/
get_header(); ?>

<div class="vw-page-wrapper clearfix">
	<?php the_simple_page_composer(); ?>
</div>

<?php get_footer(); ?>