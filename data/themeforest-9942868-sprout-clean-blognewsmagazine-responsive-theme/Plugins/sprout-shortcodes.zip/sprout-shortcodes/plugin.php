<?php
/*
Plugin Name: Sprout Shortcodes
Plugin URI: http://envirra.com
Description: Shortcodes for Sprout Theme
Version: 1.0.0
Author: Envirra
Author URI: http://envirra.com
*/

if ( ! defined( 'VW_CONST_ENABLE_SHORTCODES' ) ) define( 'VW_CONST_ENABLE_SHORTCODES', true );